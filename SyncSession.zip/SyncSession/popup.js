// popup.js

const socket = new WebSocket('ws://localhost:8080');
let url;
let sessionId;
let browserId;

document.getElementById('getSession').addEventListener('click', () => {
  // Get the current active tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    // Reload the current tab
    const currentTab = tabs[0];
    const currentTabId = currentTab.id;
    // Listen for the tab to be fully loaded
    chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo, tab) {
      if (tabId === currentTabId && changeInfo.status === 'complete') {
        // Remove this listener as it's no longer needed
        chrome.tabs.onUpdated.removeListener(listener);
        const sessionData = getSessionData();
        const socket = new WebSocket('ws://localhost:8080');
        sessionId = generateSessionId(); // Replace with actual session ID
        browserId = getOrCreateBrowserId(); // Replace with your unique identifier logic
        url = currentTab.url
        socket.onopen = () => {
          //alert("WebSocket connection established");
          socket.send(JSON.stringify({ type: 'CREATE_SESSION', data: { sessionData, sessionId, browserId, url } }));
          const displaySessionId = document.getElementById('displaySessionId');
          displaySessionId.innerHTML = `Session ID: ${sessionId}`
        };
      }
    });
    chrome.tabs.reload(currentTabId);
    chrome.tabs.sendMessage(currentTabId, {
      type: 'TEXT_SYNC',
      sessionId: sessionId,
      browserId: browserId
    }, (response) => {
      if (response && response.status === 'success') {
        alert('Text sync begins');
      } else {
        alert('Failed to start text sync');
      }
    })
  });
})

document.getElementById('setSession').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    // chrome.runtime.reload();
    const socket = new WebSocket('ws://localhost:8080');
    const currentTabId = tabs[0].id;
    sessionId = document.getElementById('sessionId').value;
    browserId = getOrCreateBrowserId();

    socket.onopen = () => {
      socket.send(JSON.stringify({ type: 'JOIN_SESSION', data: { sessionId, browserId } }));
    };
    socket.onmessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.type === 'SESSION_UPDATE') {
        // alert(JSON.stringify(message.data))
        const activeBrowsers = message.data.activeBrowsers;
        if (Object.keys(activeBrowsers).length === 0 && activeBrowsers.constructor === Object) {
          alert('Please enter a valid session ID');
        } else {
          for (const browser of activeBrowsers) {
            if (browser === browserId) {
              alert("Your browser ID has been saved and populated!");
              const displaySessions = document.getElementById('openSessions');
              displaySessions.innerHTML = `Active Browsers: ${JSON.stringify(activeBrowsers)}`;
              displaySessions.innerHTML += `<br>Your Browser ID is: ${browserId}`;
            }
          }
        }
      }
      const sessionData = message.data.sessionData;
      url = message.data.url
      chrome.tabs.update(currentTabId, { url: url });
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        if (tabId === currentTabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.runtime.sendMessage({
            type: 'SET_SESSION_DATA',
            data: sessionData
          }, (response) => {
            if (response && response.status === 'success') {
              alert('Session data set successfully. Refresh the page to apply changes.');
              // chrome.tabs.update(currentTabId, { url: url });
              chrome.tabs.sendMessage(currentTabId, {
                type: 'TEXT_SYNC',
                sessionId: sessionId,
                browserId: browserId
              }, (response) => {
                if (response && response.status === 'success') {
                  alert('Text sync begins');
                } else {
                  alert('Failed to start text sync');
                }
              })
            } else {
              alert('Failed to set session data.');
            }
          })
        }
      })
    }
  })
});

document.getElementById('leaveSession').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const socket = new WebSocket('ws://localhost:8080');
    /*const browserId = localStorage.getItem('browserId');*/
    const currentTabId = tabs[0].id;
    sessionId = document.getElementById('sessionId').value;
    browserId = getOrCreateBrowserId();
    socket.onopen = () => {
      socket.send(JSON.stringify({ type: 'LEAVE_SESSION', data: { sessionId, browserId } }));
    };
    /*alert(JSON.stringify(sessionData));*/
    // Send message to background script to set session data
    chrome.runtime.sendMessage({
      type: 'UNSET_SESSION_DATA'
    }, (response) => {
      if (response && response.status === 'success') {
        alert('Session data unset successfully. Refresh the page to apply changes.');
        chrome.tabs.update(currentTabId, { url: url });
      } else {
        alert('Failed to unset session data.');
      }
    });
  })
})
