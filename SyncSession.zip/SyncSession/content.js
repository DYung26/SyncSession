// content.js


function generateSessionId() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const length = 10;
  let sessionId = '';
  for (let i = 0; i < length; i++) {
    sessionId += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return sessionId;
}

// Function to update caret and textbox position
function updateCaretPosition(input, customCaret, floatingTextbox) {
  const caretPos = input.selectionStart;
  const rect = input.getBoundingClientRect();
  const textBeforeCaret = input.value.slice(0, caretPos);
  const span = document.createElement('span');
  span.style.visibility = 'hidden';
  span.style.whiteSpace = 'pre';
  span.textContent = textBeforeCaret;
  document.body.appendChild(span);

  const spanRect = span.getBoundingClientRect();
  const caretTop = rect.top + window.scrollY;
  const caretLeft = rect.left + spanRect.width + window.scrollX;

  customCaret.style.top = `${caretTop}px`;
  customCaret.style.left = `${caretLeft}px`;

  floatingTextbox.style.top = `${caretTop - 30}px`;
  floatingTextbox.style.left = `${caretLeft}px`;

  document.body.removeChild(span);
}

// Attach event listeners to input elements
function attachCaret(input, socket, sessionId, browserId) {
  const customCaret = document.createElement('div');
  customCaret.id = 'customCaret';
  customCaret.style.position = 'absolute';
  customCaret.style.width = '2px';
  customCaret.style.height = '20px';
  customCaret.style.backgroundColor = 'blue';
  customCaret.style.zIndex = '1000';
  document.body.appendChild(customCaret);

  const floatingTextbox = document.createElement('input');
  floatingTextbox.id = 'floatingTextbox';
  floatingTextbox.type = 'text';
  floatingTextbox.style.position = 'absolute';
  floatingTextbox.style.width = '100px';
  floatingTextbox.style.zIndex = '1001';
  document.body.appendChild(floatingTextbox);

  input.addEventListener('input', () => {
    updateCaretPosition(input, customCaret, floatingTextbox);

    const text = input.value;
    const caretColor = getRandomColor();

    if (socket.readyState === WebSocket.OPEN) {
      const message = JSON.stringify({ type: 'TEXT_CARET', data: { sessionId, browserId, text, caretColor } });
      socket.send(message);
    }
  });

  input.addEventListener('click', () => {
    updateCaretPosition(input, customCaret, floatingTextbox);
  });
  input.addEventListener('keyup', () => {
    updateCaretPosition(input, customCaret, floatingTextbox);
  });
  input.addEventListener('keydown', () => {
    updateCaretPosition(input, customCaret, floatingTextbox);
  });
}

// Function to extract session data
function getSessionData() {
    // Example: Extracting session token and user ID from localStorage
    const sessionToken = localStorage.getItem('sessionToken'); // Assuming the session token is stored in localStorage
    const userId = localStorage.getItem('userId'); // Assuming the user ID is stored in localStorage
    // Extracting workspace ID from the URL
    const workspaceId = window.location.pathname.split('/').pop(); // Assuming the workspace ID is part of the URL
    // Create session data object
    // Retrieve HttpOnly cookies and add them to sessionData
    const accessToken = getCookie('accessToken', (accessToken) => {
      sessionData.accessToken = accessToken;
      console.log('Session data received:', sessionData);
    });
    const sessionData = {
      sessionToken,
      userId,
      workspaceId,
      accessToken,
    };

    return sessionData;
}

// Function to get the value of a specific cookie
function getCookie(name, callback) {
  chrome.cookies.get({ url: 'https://api.imperial.learnchameleon.com/menu', name: name }, (cookie) => {
    if (cookie) {
      console.log('Cookie value:', cookie.value);
      callback(cookie.value);
    } else {
        callback(null);
    }
  });
}

function getOrCreateBrowserId() {
  let browserId = localStorage.getItem('browserId');
  if (!browserId) {
    browserId = 'browser_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('browserId', browserId);
  }
  return browserId;
}

/*const browserId = getOrCreateBrowserId();*/

function getRandomColor() {
  // Generate random RGB values
  const r = Math.floor(Math.random() * 256);
  const g = Math.floor(Math.random() * 256);
  const b = Math.floor(Math.random() * 256);
  // Construct color string in hex format
  return '#' + r.toString(16).padStart(2, '0') + g.toString(16).padStart(2, '0') + b.toString(16).padStart(2, '0');
}

function renderCursor(cursorData, browserId) {
  // Create or update cursor element with respective color
  let cursorElement = document.getElementById(cursorData.browserId);
  if (!cursorElement) {
    cursorElement = document.createElement('div');
    cursorElement.id = cursorData.browserId;
    document.body.appendChild(cursorElement);
  }
  cursorElement.style.position = 'absolute';
  cursorElement.style.left = cursorData.x + 'px';
  cursorElement.style.top = cursorData.y + 'px';
  cursorElement.style.width = '10px';
  cursorElement.style.height = '10px';
  cursorElement.style.backgroundColor = cursorData.color;
}
