// content1.js


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'TEXT_SYNC') {
    const inputHandler = (event) => {
      if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
        const data = {
          type: event.target.tagName,
          value: event.target.value,
          id: event.target.id,
          class: event.target.className,
          name: event.target.name,
          timestamp: Date.now()
        };
        data.targetIdentifier = getTargetIdentifier(event.target);
        const sessionId = message.sessionId;
        const browserId = message.browserId;
        sendData(data, sessionId, browserId);
      }
    };
    document.addEventListener('input', inputHandler);
    sendResponse({ status: 'success' });
  }
  if (message.type === 'TEXT_UPDATE') {
    writeDataToPage(message.data);
    sendResponse({ status: 'success' });
  }
  return true;
});

function sendData(data, sessionId, browserId) {
  chrome.runtime.sendMessage({
    type: 'TEXT_CARET',
    data: data,
    sessionId: sessionId,
    browserId: browserId
  }, (response) => {
    if (response && response.status === 'success') {
      console.log('Text message sent successfully.');
    } else {
      console.error('Failed to send text message.');
    }
  });
}

function getTargetIdentifier(target) {
  if (target.id) {
    return `#${target.id}`;
  } else if (target.name) {
    return `[name="${target.name}"]`;
  } else if (target.className) {
    return `.${target.className.split(' ').join('.')}`;
  } else {
    return target.tagName.toLowerCase();
  }
}
  
function writeDataToPage(data) {
  let targetInput;
  if (data.targetIdentifier.startsWith('#')) {
    targetInput = document.querySelector(data.targetIdentifier);
  } else if (data.targetIdentifier.startsWith('.')) {
    targetInput = document.querySelector(data.targetIdentifier);
  } else if (data.targetIdentifier.startsWith('[name=')) {
    targetInput = document.querySelector(data.targetIdentifier);
  } else {
    targetInput = document.querySelector(data.targetIdentifier);
  }
  
  if (targetInput) {
    targetInput.value = data.value;
  } else {
    console.warn('Target input not found');
  }
}
