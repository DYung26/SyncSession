// background.js

let socket;
let isSocketConnected = false;
let messageQueue = [];

// Connect to the WebSocket server
function connectWebSocket() {
  socket = new WebSocket('ws://localhost:8080');

  socket.onopen = () => {
    console.log('WebSocket connection opened.');
    isSocketConnected = true;
    // Process any queued messages
    while (messageQueue.length > 0) {
      const { data, sessionId, browserId } = messageQueue.shift();
      sendData(data, sessionId, browserId);
    }
  };

  socket.onmessage = (event) => {
    const message = JSON.parse(event.data);
    if (message.type === 'TEXT_UPDATE') {
      // Relay the message to the content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          const currentTabId = tabs[0].id;
          chrome.tabs.sendMessage(currentTabId, {
            type: 'TEXT_UPDATE',
            data: message.data
          }, (response) => {
            if (response && response.status === 'success') {
              console.log('Text updated');
            } else {
              console.log('Failed to update text');
            }
          });
        }
      });
    }
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
    isSocketConnected = false;
  };

  socket.onclose = () => {
    console.log('WebSocket connection closed.');
    isSocketConnected = false;
  };
}

// Send data through the WebSocket
function sendData(data, sessionId, browserId) {
  if (isSocketConnected) {
    socket.send(JSON.stringify({ type: 'TEXT_CARET', data: data, sessionId: sessionId, browserId: browserId }));
  } else {
    messageQueue.push({ data, sessionId, browserId });
    if (socket.readyState === WebSocket.CLOSED || socket.readyState === WebSocket.CLOSING) {
      connectWebSocket();
    }
  }
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'TEXT_CARET') {
    const { data, sessionId, browserId } = message;
    sendData(data, sessionId, browserId);
    sendResponse({ status: 'success' });
  }
});

// Connect WebSocket on script load
connectWebSocket();


// Listen for messages from the popup window
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SET_SESSION_DATA') {
    const sessionData = message.data;
    const sessionToken = sessionData[0].sessionToken;
    const userId = sessionData[0].userId;
    const workspaceId = sessionData[0].workspaceId;
    const accessToken = sessionData[0].accessToken;
    // Set localStorage items
    if (sessionToken) {
        chrome.storage.local.set({ 'sessionToken': sessionToken });
    }
    if (userId) {
        chrome.storage.local.set({ 'userId': userId });
    }
    if (workspaceId) {
        chrome.storage.local.set({ 'workspaceId': workspaceId });
    }

    // Set the accessToken cookie
    chrome.cookies.set({
        url: 'https://api.imperial.learnchameleon.com/menu',
        name: 'accessToken',
        value: accessToken,
        domain: 'api.imperial.learnchameleon.com',
        expirationDate: Math.floor((Date.now() + 86400000) / 1000), // Expires in 1 day
        secure: true,
        httpOnly: true,
        sameSite: 'strict'
    }, (cookie) => {
        if (cookie) {
            sendResponse({ status: 'success' });
        } else {
            sendResponse({ status: 'error' });
        }
    });

    // Indicate that we will asynchronously respond
    return true;
  }
});

// Listen for messages from the popup window
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'UNSET_SESSION_DATA') {
    // Set localStorage items
    chrome.storage.local.remove('sessionToken');
    chrome.storage.local.remove('userId');
    chrome.storage.local.remove('workspaceId');
    // Set the accessToken cookie
    chrome.cookies.remove({
      url: 'https://api.imperial.learnchameleon.com/menu',
      name: 'accessToken'
    }, (cookie) => {
        if (cookie) {
            sendResponse({ status: 'success' });
        } else {
            sendResponse({ status: 'error' });
        }
    });
    // Indicate that it will asynchronously respond
    return true;
  }
});
