const WebSocket = require('ws');

// Create a WebSocket server
const wss = new WebSocket.Server({ port: 8080 });

// Store session data
let sessions = {};

wss.on('connection', (ws) => {
    ws.on('message', (message) => {
        const data = JSON.parse(message);

        switch (data.type) {
            case 'CREATE_SESSION':
                handleCreateSession(data.data, ws);
                break;
            case 'JOIN_SESSION':
                handleJoinSession(data.data, ws);
                break;
            case 'LEAVE_SESSION':
                handleLeaveSession(data.data);
                break;
            case 'TEXT_CARET':
                handleTextCaret(data.data, data.sessionId, data.browserId);
                break;
            default:
                console.error('Unknown message type:', data.type);
        }
    });

    ws.on('close', () => {
        // Handle client disconnect
        /*for (let sessionId in sessions) {
            const session = sessions[sessionId];
            session.activeBrowsers = session.activeBrowsers.filter(browser => browser.ws !== ws);
            broadcastSessionUpdate(sessionId);
        }*/
    });
});

function handleCreateSession({ sessionData, sessionId, browserId, url }, ws) {
    if (!sessions[sessionId]) {
        sessions[sessionId] = { activeBrowsers: [], sessionDataObj: [], url: url };
    }
    sessions[sessionId].activeBrowsers.push({ id: browserId, ws });
    sessions[sessionId].sessionDataObj.push(sessionData);
    broadcastSessionUpdate(sessionId);
}

function handleJoinSession({ sessionId, browserId }, ws) {
    if (!sessions[sessionId]) {
        const activeBrowsers = {}
        const sessionData = {}
        const message = JSON.stringify({ type: 'SESSION_UPDATE', data: { activeBrowsers, sessionData} });
        ws.send(message)
    } else {
        sessions[sessionId].activeBrowsers.push({ id: browserId, ws });
        broadcastSessionUpdate(sessionId);
    }
}

function handleLeaveSession({ sessionId, browserId }) {
    if (sessions[sessionId]) {
        sessions[sessionId].activeBrowsers = sessions[sessionId].activeBrowsers.filter(browser => browser.id !== browserId);
        broadcastSessionUpdate(sessionId);
    }
}

function handleTextCaret(text, sessionId, browserId) {
    broadcastTextCaretUpdate(text, sessionId, browserId);
}

function broadcastSessionUpdate(sessionId) {
    const session = sessions[sessionId];
    const activeBrowsers = session.activeBrowsers.map(browser => browser.id);
    const sessionData = session.sessionDataObj;
    const url = session.url
    const message = JSON.stringify({ type: 'SESSION_UPDATE', data: { activeBrowsers, sessionData, url } });
    session.activeBrowsers.forEach(browser => browser.ws.send(message));
}

function broadcastTextCaretUpdate(textData, sessionId, browserId) {
    const message = JSON.stringify({ type: 'TEXT_UPDATE', data: textData });
    sessions[sessionId].activeBrowsers.forEach(browser => browser.ws.send(message));
    //   .filter(browser => browser.id !== browserId)
    console.log(JSON.parse(message).data.value);
}

console.log('WebSocket server is running on ws://localhost:8080');
